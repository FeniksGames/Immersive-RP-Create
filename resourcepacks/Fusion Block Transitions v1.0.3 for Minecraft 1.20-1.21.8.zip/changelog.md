### Fusion Block Transitions 1.0.3
- Account for 1.21.9 pack.mcmeta format changes
- Fixed warnings about missing particle sprites

### Fusion Block Transitions 1.0.2
- Fixed breaking overlay being layered multiple times for blocks with transitions

### Fusion Block Transitions 1.0.1
- Updated resource pack icon

### Fusion Block Transitions 1.0.0
- Initial release of Fusion Block Transitions
